﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApi.Models;

namespace WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CalculationsController : ControllerBase
    {
        private readonly ForexDbContext _context;

        public CalculationsController(ForexDbContext context)
        {
            _context = context;
        }

        // GET: api/Calculations
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Calculation>>> GetCalculations()
        {
            return await _context.Calculations.ToListAsync();
        }

        // GET: api/Calculations/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Calculation>> GetCalculation(int id)
        {
            var calculation = await _context.Calculations.FindAsync(id);

            if (calculation == null)
            {
                return NotFound();
            }

            return calculation;

        }

        // PUT: api/Calculations/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutCalculation(int id, Calculation calculation)
        {
            if (id != calculation.Id)
            {
                return BadRequest();
            }

            _context.Entry(calculation).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CalculationExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Calculations
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<Calculation>> PostCalculation(Calculation calculation)
        {
            string fromCU = calculation.fromCurrency;
            string toCU = calculation.toCurrency;
            var amount1 = calculation.amount;


            //edited by Dhanshri
            //if amount is 0
            if (amount1 == 0)
            {
                calculation.convertedAmounted = 0;
            }

            var RateINR = 74.27;
            var RateUSD = 1;
            var RateEuro = 0.85;
            var RateYen = 111.62;
            var RatePound = 0.73;

            decimal convertedRate;

            //if from currency and to currency are same
            if (fromCU.Equals(toCU))
            {
                calculation.convertedAmounted = amount1;
            }
            else
            {
                //converting INR to other Currency
                if (fromCU.Equals("INR"))
                {
                    if (fromCU.Equals("INR") && toCU.Equals("USD"))
                    {
                        // convertedRate = amount1 / Convert.ToDecimal(RateINR);

                        convertedRate = Convert.ToDecimal(1 / Convert.ToDouble(RateINR) * Convert.ToDouble(RateUSD));
                        convertedRate = convertedRate * amount1;
                        calculation.convertedAmounted = convertedRate;

                    }
                    else if (fromCU.Equals("INR") && toCU.Equals("EURO"))
                    {
                        convertedRate = Convert.ToDecimal(1 / Convert.ToDouble(RateINR) * Convert.ToDouble(RateEuro));
                        convertedRate = convertedRate * amount1;
                        calculation.convertedAmounted = convertedRate;

                    }
                    else if (fromCU.Equals("INR") && toCU.Equals("POUND"))
                    {
                        convertedRate = Convert.ToDecimal(1 / Convert.ToDouble(RateINR) * Convert.ToDouble(RatePound));
                        convertedRate = convertedRate * amount1;
                        calculation.convertedAmounted = convertedRate;

                    }
                    else if (fromCU.Equals("INR") && toCU.Equals("YEN"))
                    {
                        convertedRate = Convert.ToDecimal(1 / Convert.ToDouble(RateINR) * Convert.ToDouble(RateYen));
                        convertedRate = convertedRate * amount1;
                        calculation.convertedAmounted = convertedRate;

                    }
                }


                //converting USD to Other Currency
                else if (fromCU.Equals("USD"))
                {
                    if (fromCU.Equals("USD") && toCU.Equals("INR"))
                    {
                        // convertedRate = amount1 / Convert.ToDecimal(RateINR);

                        convertedRate = Convert.ToDecimal(1 / Convert.ToDouble(RateUSD) * Convert.ToDouble(RateINR));
                        convertedRate = convertedRate * amount1;
                        calculation.convertedAmounted = convertedRate;

                    }
                    else if (fromCU.Equals("USD") && toCU.Equals("EURO"))
                    {
                        convertedRate = Convert.ToDecimal(1 / Convert.ToDouble(RateUSD) * Convert.ToDouble(RateEuro));
                        convertedRate = convertedRate * amount1;
                        calculation.convertedAmounted = convertedRate;

                    }
                    else if (fromCU.Equals("USD") && toCU.Equals("POUND"))
                    {
                        convertedRate = Convert.ToDecimal(1 / Convert.ToDouble(RateUSD) * Convert.ToDouble(RatePound));
                        convertedRate = convertedRate * amount1;
                        calculation.convertedAmounted = convertedRate;

                    }
                    else if (fromCU.Equals("USD") && toCU.Equals("YEN"))
                    {
                        convertedRate = Convert.ToDecimal(1 / Convert.ToDouble(RateUSD) * Convert.ToDouble(RateYen));
                        convertedRate = convertedRate * amount1;
                        calculation.convertedAmounted = convertedRate;

                    }
                }


                //Converting Euro to other Currency
                else if (fromCU.Equals("EURO"))
                {
                    if (fromCU.Equals("EURO") && toCU.Equals("INR"))
                    {
                        // convertedRate = amount1 / Convert.ToDecimal(RateINR);

                        convertedRate = Convert.ToDecimal(1 / Convert.ToDouble(RateEuro) * Convert.ToDouble(RateINR));
                        convertedRate = convertedRate * amount1;
                        calculation.convertedAmounted = convertedRate;

                    }
                    else if (fromCU.Equals("EURO") && toCU.Equals("USD"))
                    {
                        convertedRate = Convert.ToDecimal(1 / Convert.ToDouble(RateEuro) * Convert.ToDouble(RateUSD));
                        convertedRate = convertedRate * amount1;
                        calculation.convertedAmounted = convertedRate;

                    }
                    else if (fromCU.Equals("EURO") && toCU.Equals("POUND"))
                    {
                        convertedRate = Convert.ToDecimal(1 / Convert.ToDouble(RateEuro) * Convert.ToDouble(RatePound));
                        convertedRate = convertedRate * amount1;
                        calculation.convertedAmounted = convertedRate;

                    }
                    else if (fromCU.Equals("EURO") && toCU.Equals("YEN"))
                    {
                        convertedRate = Convert.ToDecimal(1 / Convert.ToDouble(RateEuro) * Convert.ToDouble(RateYen));
                        convertedRate = convertedRate * amount1;
                        calculation.convertedAmounted = convertedRate;

                    }
                }

                //Converting Pound to other Currency
                else if (fromCU.Equals("POUND"))
                {
                    if (fromCU.Equals("POUND") && toCU.Equals("INR"))
                    {
                        // convertedRate = amount1 / Convert.ToDecimal(RateINR);

                        convertedRate = Convert.ToDecimal(1 / Convert.ToDouble(RatePound) * Convert.ToDouble(RateINR));
                        convertedRate = convertedRate * amount1;
                        calculation.convertedAmounted = convertedRate;

                    }
                    else if (fromCU.Equals("POUND") && toCU.Equals("EURO"))
                    {
                        convertedRate = Convert.ToDecimal(1 / Convert.ToDouble(RatePound) * Convert.ToDouble(RateEuro));
                        convertedRate = convertedRate * amount1;
                        calculation.convertedAmounted = convertedRate;

                    }
                    else if (fromCU.Equals("POUND") && toCU.Equals("USD"))
                    {
                        convertedRate = Convert.ToDecimal(1 / Convert.ToDouble(RatePound) * Convert.ToDouble(RateUSD));
                        convertedRate = convertedRate * amount1;
                        calculation.convertedAmounted = convertedRate;

                    }
                    else if (fromCU.Equals("POUND") && toCU.Equals("YEN"))
                    {
                        convertedRate = Convert.ToDecimal(1 / Convert.ToDouble(RatePound) * Convert.ToDouble(RateYen));
                        convertedRate = convertedRate * amount1;
                        calculation.convertedAmounted = convertedRate;

                    }
                }

                //Converting Yen to other Currency
                else if (fromCU.Equals("YEN"))
                {
                    if (fromCU.Equals("YEN") && toCU.Equals("INR"))
                    {
                        // convertedRate = amount1 / Convert.ToDecimal(RateINR);

                        convertedRate = Convert.ToDecimal(1 / Convert.ToDouble(RateYen) * Convert.ToDouble(RateINR));
                        convertedRate = convertedRate * amount1;
                        calculation.convertedAmounted = convertedRate;

                    }
                    else if (fromCU.Equals("YEN") && toCU.Equals("EURO"))
                    {
                        convertedRate = Convert.ToDecimal(1 / Convert.ToDouble(RateYen) * Convert.ToDouble(RateEuro));
                        convertedRate = convertedRate * amount1;
                        calculation.convertedAmounted = convertedRate;

                    }
                    else if (fromCU.Equals("YEN") && toCU.Equals("USD"))
                    {
                        convertedRate = Convert.ToDecimal(1 / Convert.ToDouble(RateYen) * Convert.ToDouble(RateUSD));
                        convertedRate = convertedRate * amount1;
                        calculation.convertedAmounted = convertedRate;

                    }
                    else if (fromCU.Equals("YEN") && toCU.Equals("POUND"))
                    {
                        convertedRate = Convert.ToDecimal(1 / Convert.ToDouble(RateYen) * Convert.ToDouble(RatePound));
                        convertedRate = convertedRate * amount1;
                        calculation.convertedAmounted = convertedRate;

                    }
                }

            }

            //aasigning of values
            calculation.fromCurrency = fromCU;
            calculation.toCurrency = toCU;
            calculation.amount = amount1;
            //calculation.convertedAmounted = convertedRate;

            _context.Calculations.Add(calculation);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetCalculation", new { id = calculation.Id }, calculation);
        }


        // DELETE: api/Calculations/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteCalculation(int id)
        {
            var calculation = await _context.Calculations.FindAsync(id);
            if (calculation == null)
            {
                return NotFound();
            }

            _context.Calculations.Remove(calculation);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool CalculationExists(int id)
        {
            return _context.Calculations.Any(e => e.Id == id);
        }
    }
}
