﻿using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApi.Models;

namespace WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CurrenciesController : ControllerBase
    {
        private readonly ForexDbContext _context;



        public CurrenciesController(ForexDbContext context)
        {
            _context = context;
        }



        // GET: api/Currencies
        [HttpGet]

        public async Task<ActionResult<IEnumerable<Currency>>> GetCurrencys()
        {
            return await _context.Currencys.ToListAsync();
        }



        // GET: api/Currencies/5
        [HttpGet("{id}")]

        public async Task<ActionResult<Currency>> GetCurrency(int id)
        {
            var currency = await _context.Currencys.FindAsync(id);



            if (currency == null)
            {
                return NotFound();
            }



            return currency;
        }



        // PUT: api/Currencies/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]

        public async Task<IActionResult> PutCurrency(int id, Currency currency)
        {
            if (id != currency.CurrencyId)
            {
                return BadRequest();
            }

            _context.Entry(currency).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CurrencyExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }



            return NoContent();
        }



        // POST: api/Currencies
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]

        public async Task<ActionResult<Currency>> PostCurrency(Currency currency)
        {
            _context.Currencys.Add(currency);
            await _context.SaveChangesAsync();



            return CreatedAtAction("GetCurrency", new { id = currency.CurrencyId }, currency);
        }



        // DELETE: api/Currencies/5
        [HttpDelete("{id}")]

        public async Task<IActionResult> DeleteCurrency(int id)
        {
            var currency = await _context.Currencys.FindAsync(id);
            if (currency == null)
            {
                return NotFound();
            }



            _context.Currencys.Remove(currency);
            await _context.SaveChangesAsync();



            return NoContent();
        }



        private bool CurrencyExists(int id)
        {
            return _context.Currencys.Any(e => e.CurrencyId == id);
        }
    }
}
