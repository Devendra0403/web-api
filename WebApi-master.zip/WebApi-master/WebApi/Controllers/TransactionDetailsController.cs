﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApi.Models;

namespace WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TransactionDetailsController : ControllerBase
    {
        
 
        private readonly ForexDbContext _context;
        public TransactionDetailsController(ForexDbContext context)
        {
            _context = context;
        }
        [HttpGet]
        public async Task<ActionResult<IEnumerable<TransactionDetail>>> GetTransactionDetails()
        {
            return await _context.TransactionDetails.ToListAsync();
        }
        [HttpGet("{id}")]
        public async Task<ActionResult<TransactionDetail>> GetTransactionDetail(int id)
        {
            var transactionDetail = await _context.TransactionDetails.FindAsync(id);
            if (transactionDetail == null)
            {
                return NotFound();
            }
            return transactionDetail;
        }
        //Post:api/TransactionDetails
        [HttpPost]
        //[Route("TransactionDetails")]
        public async Task<ActionResult<TransactionDetail>> PostTransactionDetails(TransactionDetail transactionDetail)
        {
            _context.TransactionDetails.Add(transactionDetail);
            await _context.SaveChangesAsync();





            return CreatedAtAction("GetTransactionDetail", new { id = transactionDetail.TransactionId }, transactionDetail);
            //_context.TransactionDetails.Add(transactionDetail);
            //await _context.SaveChangesAsync();
            //return CreatedAtAction("GetTransactionDetail", new { id = transactionDetail.TransactionId }, transactionDetail);
            // ReadOnlySpan<byte> jsonString = default;
            //var transactionModels = JsonSerializer.Deserialize<List<TransactionDetail>>(jsonString);
            //transactionDetail = transactionModels.First();
        }
    }



}

