﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApi.Models;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminLoginController : ControllerBase
    {
        private UserManager<ApplicationUser> _userManager;
        private SignInManager<ApplicationUser> _signInManager;
        private readonly ApplicationSettings _appSettings;
        public AdminLoginController(UserManager<ApplicationUser> userManager, SignInManager<ApplicationUser> signInManager, IOptions<ApplicationSettings> appSettings)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            _appSettings = appSettings.Value;
        }
        private readonly ForexDbContext _context;
        [HttpPost]
        //POST : /api/AdminLogin/PostLogin
        public async Task<IActionResult> PostAdmin(Admin adminLogin)
        {
            _context.Admins.Add(adminLogin);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetAdmin", new { id = adminLogin.AdminId }, adminLogin);


            //var user = await _userManager.FindByNameAsync(adminLogin.UserName);
            //if (user != null && await _userManager.CheckPasswordAsync(user, adminLogin.PassWord))
            //{
            //    return CreatedAtAction("GetAdmin", new { id = adminLogin.AdminId }, adminLogin);
            //}
            //else
            //{
            //    return BadRequest(new { message = "Username or password is incorrect." });
            //}
        }
    }
}
