﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebApi.Models
{
    public class Currencies
    {
        [Key]
        public int CurrencyId { get; set; }

        public int AdminId { get; set; }

        public string CurrencyName { get; set; }

        public decimal CurrencyRate { get; set; }

        public string CountryName { get; set; }

        public string CurrencyDate { get; set; }
    }
}
