﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace WebApi.Models
{
    public class TransactionDetail
    {
        [Key]
        public int TransactionId { get; set; }



        [Required]
        //[ForeignKey("UserId")]
        public int UserId { get; set; }



        [Required]
        [Column(TypeName = "nvarchar(100)")]
        public string SenderBankName { get; set; }



        [Required]
        [Column(TypeName = "nvarchar(100)")]
        public string SenderAccNo { get; set; }



        [Required]
        [Column(TypeName = "nvarchar(100)")]
        public string RecipientName { get; set; }



        [Required]
        [Column(TypeName = "nvarchar(100)")]
        public string RecipientAccNo { get; set; }



        [Required]
        [Column(TypeName = "nvarchar(100)")]
        public DateTime TransactionDate { get; set; }



        [Required]
        [Column(TypeName = "decimal(18,2)")]
        public decimal TransactionFee { get; set; }
    }
}
