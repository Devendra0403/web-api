﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApi.Models
{
    public class Calculation
    {
        public int Id { get; set; }
        public string fromCurrency { get; set; }
        public string toCurrency { get; set; }
        public decimal amount { get; set; }
        public decimal convertedAmounted { get; set; }
    }
}
