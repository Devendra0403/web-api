﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace WebApi.Models
{
    public class Currency
    {
        [Key]
        public int CurrencyId { get; set; }



        // Foreign key   
        [Display(Name = "Admin")]
        public virtual int AdminId { get; set; }



        [ForeignKey("AdminId")]
        public virtual Admin Admins { get; set; }



        [Column(TypeName = "nvarchar(25)")]
        public string CurrencyName { get; set; }


        [Column(TypeName = "decimal(18, 2)")]
        public decimal CurrencyRate { get; set; }


        [Column(TypeName = "nvarchar(25)")]
        public string CountryName { get; set; }



        public string CurrencyDate { get; set; }
    }
}
