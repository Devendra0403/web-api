﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore.SqlServer;

namespace WebApi.Models
{
    public class ForexDbContext : DbContext
    {
        public ForexDbContext(DbContextOptions<ForexDbContext> options) : base(options)
        {
        }
        public DbSet<Currency> Currencys { get; set; }
        public DbSet<Admin> Admins { get; set; }
        public DbSet<TransactionDetail> TransactionDetails { get; set; }
        public DbSet<Currencies> Currencie { get; set; }
        public DbSet<Calculation> Calculations { get; set; }


    }
}
